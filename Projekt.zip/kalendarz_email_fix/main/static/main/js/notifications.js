document.addEventListener('DOMContentLoaded', function() {
  const btn = document.getElementById('btn-notifications');
  if (!btn) return;
  btn.addEventListener('click', function(e) {
    e.preventDefault();
    fetch('/ajax/notifications/')
      .then(res => res.json())
      .then(data => {
        let html = '<h2>Powiadomienia</h2><ul>';
        data.notifications.forEach(n => {
          html += `<li>[${n.type.toUpperCase()}] ${new Date(n.at).toLocaleString()}: ${n.message}</li>`;
        });
        html += '</ul>';
        document.getElementById('content').innerHTML = html;
      })
      .catch(() => alert('Błąd ładowania powiadomień.'));
  });
});
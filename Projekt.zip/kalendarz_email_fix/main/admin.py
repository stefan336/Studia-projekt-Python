from django.contrib import admin
from .models import Ocena

admin.site.register(Ocena)
